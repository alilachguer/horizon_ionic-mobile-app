﻿using APIRSSReader.Models;
using APIRSSReader.Models.Persistance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APIRSSReader.Controllers
{
    public class ArticlesController : ApiController
    {
        // GET: api/Articles
        public List<Article> Get()
        {
            DataBaseCommunication dataBaseCommunication = new DataBaseCommunication("server=108.167.183.94;database=benbrahi_horizon;uid=benbrahi_horizon;pwd=aaaaaa12");
            return dataBaseCommunication.GetArticles();
        }


        // POST: api/Articles
        public void Post([FromBody]Person person)
        {
            if( person.Login.Equals("CiPhantom") && person.Password.Equals("lksPMnze"))
            {

                OpmlHandler opmlHandler = new OpmlHandler("./rss.opml");
                Dictionary<string, string> urls = new Dictionary<string, string>();
                urls = opmlHandler.getListeJourneaux();

                List<Article> articles = new List<Article>();
                Feeder f = new Feeder(urls);
                articles = f.getArticles();

                DataBaseCommunication dataBaseCommunication = new DataBaseCommunication("server=108.167.183.94;database=benbrahi_horizon;uid=benbrahi_horizon;pwd=aaaaaa12");

                dataBaseCommunication.SaveArticles(articles);
            }   
        }

        [Route("api/articles/postuser")]
        [HttpPost]
        public Boolean PostUser([FromBody] User user)
        {
            DataBaseCommunication dataBaseCommunication = new DataBaseCommunication("server=108.167.183.94;database=benbrahi_horizon;uid=benbrahi_horizon;pwd=aaaaaa12");
            return dataBaseCommunication.AddUser(user);
        }

        [Route("api/articles/checkuser")]
        [HttpPost]
        public Boolean CheckUser([FromBody] User user)
        {
            DataBaseCommunication dataBaseCommunication = new DataBaseCommunication("server=108.167.183.94;database=benbrahi_horizon;uid=benbrahi_horizon;pwd=aaaaaa12");
            return dataBaseCommunication.CheckUser(user);
        }
    }
}
