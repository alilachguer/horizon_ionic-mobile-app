﻿using MySql.Data.MySqlClient;
using APIRSSReader.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIRSSReader.Models
.Persistance
{
    public class DataBaseCommunication
    {
        public MySqlConnection connection;
        public string urlConnection = "";

        public DataBaseCommunication(string UrlConnection)
        {
            try
            {
                connection = new MySqlConnection(UrlConnection);
                connection.Open();
                this.urlConnection = UrlConnection;
                Console.WriteLine("Connection Succesded");
            }
            catch(MySqlException e)
            {
                Console.WriteLine("DataBase opening failed! Maybe bad url connection ?" + e.Message);
            }
        }

        public Boolean CheckUser(User user)
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM utilisateur where id_user= "+user.Id+" and nom = '"+user.Nom.Replace("'","''")+"'";
            MySqlDataReader msdr = cmd.ExecuteReader();
            while (msdr.Read())
            {
                return true; 
            }
            return false; 
        }

        public Boolean AddUser(User user)
        {
            if (CheckUser(user))
            {
                return false;
            }
            else
            {
                connection = new MySqlConnection(this.urlConnection);
                connection.Open();
                MySqlCommand cmd = this.connection.CreateCommand();
                cmd.CommandText = "insert into utilisateur values ("+user.Id+",'"+user.Nom.Replace("'", "''")+"')";
                try
                {
                    cmd.ExecuteNonQuery();
                    return true; 
                }
                catch
                {
                    return false; 
                }
                
            }
        }

        public void SaveArticles(List<Article> articles)
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            foreach(Article article in articles)
            {
                string statement = String.Empty;
                if (article.Image == null)
                {
                    statement = "INSERT INTO article (source, titre, link, description) values ('"
                    + article.Source.Replace("'", "''") + "', '" + article.Titre.Replace("'", "''") + "', '"
                    + article.Link.Replace("'", "''") + "', '" + article.Description.Replace("'", "''") + "')";
                }
                else
                {
                    statement = "INSERT INTO article (source, titre, link, description, Image) values ('"
                   + article.Source.Replace("'", "''") + "', '" + article.Titre.Replace("'", "''") + "', '"
                   + article.Link.Replace("'", "''") + "', '" + article.Description.Replace("'", "''") + "', '"
                   + article.Image.Replace("'", "''") + "')";
                }

                try
                {
                    cmd.CommandText = statement;
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = String.Empty;
                }
                catch(MySqlException e)
                {
                    Console.WriteLine("Cette requête cause problème : " + statement + " \n The exception say " + e.Message);
                }

            }
        }

        public List<Article> GetArticles()
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            List<Article> articles = new List<Article>();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM article";
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();

            while (mySqlDataReader.Read())
            {
                Article article = new Article();
                article.Source = mySqlDataReader.GetString(2);
                article.Titre = mySqlDataReader.GetString(3);
                article.Link = mySqlDataReader.GetString(4);
                article.Description = mySqlDataReader.GetString(5);
                try
                {
                    article.Image = mySqlDataReader.GetString(6);
                }
                catch { 
                    //You can add some treats here
                }
                article.Score = mySqlDataReader.GetInt32(7);

                articles.Add(article);
            }


            return articles; 
        }

        

    }
}
