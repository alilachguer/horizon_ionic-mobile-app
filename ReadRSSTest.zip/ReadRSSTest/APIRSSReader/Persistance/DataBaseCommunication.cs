﻿using MySql.Data.MySqlClient;
using APIRSSReader.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIRSSReader.Models
.Persistance
{
    public class DataBaseCommunication
    {
        public MySqlConnection connection;

        public DataBaseCommunication(string UrlConnection)
        {
            try
            {
                connection = new MySqlConnection(UrlConnection);
                connection.Open();
            }
            catch
            {
                Console.WriteLine("DataBase opening failed! Maybe bad url connection ?");
            }
        }

        public void SaveArticles(List<Article> articles)
        {
            MySqlCommand cmd = this.connection.CreateCommand();
            foreach(Article article in articles)
            {
                string statement = String.Empty;
                if (article.Image == null)
                {
                    statement = "INSERT INTO articles (source, titre, link, description) values ('"
                    + article.Source.Replace("'", "''") + "', '" + article.Titre.Replace("'", "''") + "', '"
                    + article.Link.Replace("'", "''") + "', '" + article.Description.Replace("'", "''") + "')";
                }
                else
                {
                    statement = "INSERT INTO articles (source, titre, link, description, Image) values ('"
                   + article.Source.Replace("'", "''") + "', '" + article.Titre.Replace("'", "''") + "', '"
                   + article.Link.Replace("'", "''") + "', '" + article.Description.Replace("'", "''") + "', '"
                   + article.Image.Replace("'", "''") + "')";
                }

                try
                {
                    cmd.CommandText = statement;
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = String.Empty;
                }
                catch(MySqlException e)
                {
                    Console.WriteLine("Cette requête cause problème : " + statement + " \n The exception say " + e.Message);
                }

            }
        }

        public List<Article> GetArticles()
        {
            List<Article> articles = new List<Article>();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM articles";
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();

            while (mySqlDataReader.Read())
            {
                Article article = new Article();
                article.Source = mySqlDataReader.GetString(1);
                article.Titre = mySqlDataReader.GetString(2);
                article.Link = mySqlDataReader.GetString(3);
                article.Description = mySqlDataReader.GetString(4);
                try
                {
                    article.Image = mySqlDataReader.GetString(5);
                }
                catch { 
                    //You can add some treats here
                }
                article.Score = mySqlDataReader.GetInt32(6);

                articles.Add(article);
            }


            return articles; 
        }

        

    }
}
