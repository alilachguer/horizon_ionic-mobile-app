﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Syndication;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using ReadRSSTest.Models;
using MySql.Data;
using ReadRSSTest.Persistance;

namespace ReadRSSTest
{
    class Program
    {
        static void Main(string[] args)
        {
            OpmlHandler opmlHandler = new OpmlHandler("C:/Users/L'Albatros/source/repos/ReadRSSTest/ReadRSSTest/rss.opml");
            Dictionary<string, string> urls = new Dictionary<string, string>();
            urls = opmlHandler.getListeJourneaux();

            List<Article> articles = new List<Article>();
            Feeder f = new Feeder(urls);
            articles = f.getArticles();
            Console.WriteLine("Lines read: " + articles.Count);

            DataBaseCommunication dataBaseCommunication = new DataBaseCommunication("server=127.0.0.1;uid=root;pwd=;database=Horizon");

            dataBaseCommunication.SaveArticles(articles);

            List<Article> articles2 = new List<Article>();
            articles2 = dataBaseCommunication.GetArticles();

            Console.WriteLine("Lines : " + articles2.Count);
            Console.ReadKey();
        }
    }
}
